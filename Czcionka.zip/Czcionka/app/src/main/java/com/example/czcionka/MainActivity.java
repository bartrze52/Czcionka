package com.example.czcionka;

import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView fontPropertiesTextView;
    private TextView fontSizeLabelTextView;
    private SeekBar fontSizeSeekBar;
    private TextView quoteTextView;
    private Button changeQuoteButton;

    private String[] quotes = {"Dzień dobry", "Good morning", "Buenos dias"};
    private int currentQuoteIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fontPropertiesTextView = findViewById(R.id.fontPropertiesTextView);
        fontSizeLabelTextView = findViewById(R.id.fontSizeLabelTextView);
        fontSizeSeekBar = findViewById(R.id.fontSizeSeekBar);
        quoteTextView = findViewById(R.id.quoteTextView);
        changeQuoteButton = findViewById(R.id.changeQuoteButton);

        fontSizeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                fontSizeLabelTextView.setText("Rozmiar: " + progress);
                quoteTextView.setTextSize(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        changeQuoteButton.setOnClickListener(v -> {
            currentQuoteIndex = (currentQuoteIndex + 1) % quotes.length;
            quoteTextView.setText(quotes[currentQuoteIndex]);
        });
    }
}